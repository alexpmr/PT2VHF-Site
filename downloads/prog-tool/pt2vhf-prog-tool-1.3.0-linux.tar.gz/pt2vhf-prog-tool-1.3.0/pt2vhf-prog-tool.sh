#!/bin/sh
# Inicia o PT2VHF Prog Tool. Requer Python 3.10+ com Tkinter e pyserial.
cd "$(dirname "$0")"
PY=${PYTHON:-python3}
if ! "$PY" -c "import tkinter" 2>/dev/null; then
  echo "Falta o Tkinter. Instale, por exemplo:"
  echo "  Debian/Ubuntu: sudo apt install python3-tk"
  echo "  Fedora:        sudo dnf install python3-tkinter"
  echo "  Arch:          sudo pacman -S tk"
  echo "  macOS:         instale o Python de https://www.python.org"
  exit 1
fi
if ! "$PY" -c "import serial" 2>/dev/null; then
  echo "Instalando pyserial para o seu usuário..."
  "$PY" -m pip install --user pyserial || {
    echo "Instale o pyserial: pacote python3-serial (Linux) ou 'pip install pyserial'"
    exit 1; }
fi
exec "$PY" main.py "$@"
